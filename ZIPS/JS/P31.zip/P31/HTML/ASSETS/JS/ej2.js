const app = document.querySelector(".app");
const imagen = document.createElement("img");
imagen.setAttribute("src", "https://via.placeholder.com/150");
imagen.setAttribute("alt", "Imagen de ejemplo");
app.append(imagen);
