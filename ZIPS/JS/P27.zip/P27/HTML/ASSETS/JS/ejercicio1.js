var res = prompt("Dime un numero");
var num = parseInt(res);
if (num % 2 == 0) {
  console.log("El numero es par");
} else {
  console.log("El numero es impar");
}
